package com.tranphuc8a.gemini_proxy;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GeminiProxyApplication {

	public static void main(String[] args) {
		SpringApplication.run(GeminiProxyApplication.class, args);
	}

}
