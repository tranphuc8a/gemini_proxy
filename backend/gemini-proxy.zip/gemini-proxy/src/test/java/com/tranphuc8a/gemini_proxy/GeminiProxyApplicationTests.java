package com.tranphuc8a.gemini_proxy;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GeminiProxyApplicationTests {

	@Test
	void contextLoads() {
	}

}
